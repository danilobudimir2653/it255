<html>


<head>

    <script src="https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.2.1.min.js"></script>
    <script src="js.js" ></script>
</head>
<body>
 <select id="combo">
     <option value="audi">Audi</option>
     <option value="mecka">Mercedes</option>
     <option value="jaguar">Jaguar</option>
 </select>
 <input type="button" value="POST" id="dugme">
 <input type="button" value="GET" id="dugme1">
<div id="ponuda">
</div>

</body>

</html>